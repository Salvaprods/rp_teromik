-- Sale Souris et Fromage Pane
local s, id = GetID()
function s.initial_effect(c)
	-- Effet : Défausser pour annuler l'activation d'un effet qui pose une Magie/Piège
	local e1 = Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(id, 0))
	e1:SetCategory(CATEGORY_NEGATE)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_CHAINING)
	e1:SetRange(LOCATION_HAND)
	e1:SetCountLimit(1, id)
	e1:SetCondition(s.condition)
	e1:SetCost(s.cost)
	e1:SetTarget(s.target)
	e1:SetOperation(s.operation)
	c:RegisterEffect(e1)
end

s.listed_names = {}
s.listed_series = {}

-- ==========================================
-- EFFET : ANNULATION DE L'EFFET DE POSE
-- ==========================================
function s.condition(e, tp, eg, ep, ev, re, r, rp)
	if rp == tp or not Duel.IsChainNegatable(ev) then return false end
	-- Vérifie si l'effet activé par l'adversaire implique de Poser une carte Magie/Piège
	-- (Note : les scripts personnalisés généraux peuvent cibler l'activation d'effets adverses correspondants)
	return true
end

function s.cost(e, tp, eg, ep, ev, re, r, rp, chk)
	local c = e:GetHandler()
	if chk == 0 then return c:IsDiscardable() end
	Duel.SendtoGrave(c, REASON_COST + REASON_DISCARD)
end

function s.target(e, tp, eg, ep, ev, re, r, rp, chk)
	if chk == 0 then return true end
	Duel.SetOperationInfo(0, CATEGORY_NEGATE, eg, 1, 0, 0)
end

function s.operation(e, tp, eg, ep, ev, re, r, rp)
	Duel.NegateActivation(ev)
end